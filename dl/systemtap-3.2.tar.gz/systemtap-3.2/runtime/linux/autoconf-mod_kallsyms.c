#include <linux/module.h>

struct mod_kallsyms mk;
