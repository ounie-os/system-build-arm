// Some defines from linux/sched.h got moved to uapi/linux/sched/types.h.
#include <linux/sched.h>
#include <uapi/linux/sched/types.h>
