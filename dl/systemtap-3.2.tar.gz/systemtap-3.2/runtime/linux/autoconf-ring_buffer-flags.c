#include <linux/ring_buffer.h>

void ___autoconf_func(void)
{
    (void)ring_buffer_lock_reserve(NULL, 0, 0);
}
